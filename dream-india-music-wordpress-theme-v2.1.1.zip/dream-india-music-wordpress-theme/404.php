<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<main id="dimp-content" class="dimp-entry" tabindex="-1"><h1>Page not found</h1><p><a class="btn" href="<?php echo esc_url(home_url('/')); ?>">Back to Dream India Production</a></p></main>
<?php get_footer(); ?>
