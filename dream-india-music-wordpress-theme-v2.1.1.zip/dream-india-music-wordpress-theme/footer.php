<?php
if (!defined('ABSPATH')) { exit; }
dimp_render_part('footer');
wp_footer();
?>
</body>
</html>
