<?php
if (!defined('ABSPATH')) { exit; }
get_header();
dimp_render_part('main');
get_footer();
