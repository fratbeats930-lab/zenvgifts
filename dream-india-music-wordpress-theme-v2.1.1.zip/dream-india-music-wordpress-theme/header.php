<?php if (!defined('ABSPATH')) { exit; } ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="dimp-skip-link" href="#dimp-content"><?php esc_html_e('Skip to content', 'dream-india-music-wordpress-theme'); ?></a>
<?php dimp_render_part('header'); ?>
