DREAM INDIA PRODUCTION — WORDPRESS MUSIC THEME 2.1.1

INSTALL
1. Apne NAYE DOMAIN ke WordPress > Appearance > Themes > Add New > Upload Theme kholein.
2. dream-india-music-wordpress-theme-v2.1.1.zip upload karein. ZIP extract na karein.
3. Install Now > Activate karein.
4. Homepage par music studio website, Our Songs aur Singing Audition Apply button aa jayenge.

WEBSITE
- Catalogue tab hata diya gaya hai.
- Our Songs homepage par previews aur alag page par supplied CSV ke 16 YouTube songs dikhata hai.
- Video preview par click karne par YouTube player khulta hai. Kisi video par YouTube embedding restrictions hon to Watch on YouTube link se kholein.
- Shop WooCommerce active aur setup hone par native products, Add to cart, Cart, Checkout aur My Account se connected hai. WooCommerce inactive ho to WhatsApp enquiry shop available rehta hai.
- Existing WordPress pages ya settings installation se delete nahin hote.
- Theme ke built-in pages ?dip_view=our-songs jaise links use karte hain. Alag pages banana zaroori nahin hai.

AUDITION REGISTRATION
Homepage ka Singing Audition Apply button https://dreamindiaproduction.online/ par visitor ko redirect karta hai.
Yeh theme aapki nayi music website ke liye hai. Audition registration pehle se chal rahi alag website par hota hai.
Appearance > Dream India Settings mein zaroorat padne par audition URL badal sakte hain.

SOCIAL LINKS
Appearance > Dream India Settings mein apne YouTube, Instagram, Facebook, Spotify aur X ke HTTPS profile URLs save karein.
Empty profiles site par hidden rehte hain. Koi profile URL guess nahin kiya gaya hai.

SONGS UPDATE
Theme assets/songs.json mein supplied CSV se converted songs hain. Original songs.csv bhi theme mein diya hai.
Har song mein title aur youtube_url required hain; artist/description optional hain.
Videos YouTube service se stream hote hain. Public YouTube video aur embedding allowed hona zaroori hai.

BUTTON FIX 2.1.1
WooCommerce block Cart ke yellow Proceed to checkout button ka text dark kiya gaya hai.
WooCommerce block Checkout ke primary buttons par bhi readable contrast rehta hai.
Theme version badli hai taaki browser naya CSS load kare. Update ke baad hosting/site cache purge karein.
Pehle se imported products ke liye CSV dobara import karne ki zaroorat nahin hai.

UPDATE 2.1.0
Latest owner CSV ke 16 song names aur links isi order mein lagaye gaye hain.
Homepage hero aur beech ke audition section mein Singing Audition Apply button diya hai.
Pehle se ye theme installed ho to Upload Theme ke baad Replace current with uploaded select karein.
Isse website settings delete nahi hoti. Purana content dikhe to hosting/site cache purge karein.

PAYMENTS UPDATE 2.1.0
WooCommerce + official Razorpay plugin install karein. Appearance > Shop & Payments se 25 services import/setup karein.
Poore steps RAZORPAY-SETUP-HINDI.txt me hain. API keys sirf WordPress payment settings me enter karein.
Theme me payment keys/bank details nahin hain. Live activation aapke Razorpay account par depend hai.

POLICY PAGES
Homepage footer aur baaki pages me Privacy Policy, Terms & Conditions, Refund Policy links added hain.
Refund Policy heading ke andar user-selected no-refund rule hai; mandatory legal rights aur billing error handling preserved hain.
Shop setup teen native editable policy pages assign karega. Existing published legal pages overwrite nahi honge.
Razorpay-compatible classic cart/checkout option ke saath setup karein.
