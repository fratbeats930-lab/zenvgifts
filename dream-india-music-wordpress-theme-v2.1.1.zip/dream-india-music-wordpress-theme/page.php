<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<main id="dimp-content" class="dimp-entry" tabindex="-1">
    <?php while (have_posts()) : the_post(); ?>
        <h1><?php the_title(); ?></h1>
        <div class="dimp-entry-content"><?php the_content(); wp_link_pages(); ?></div>
    <?php endwhile; ?>
</main>
<?php get_footer(); ?>
