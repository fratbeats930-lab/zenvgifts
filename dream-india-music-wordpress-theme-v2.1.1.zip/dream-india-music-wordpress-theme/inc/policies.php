<?php
/** Published policy content and checkout links, without automatic database writes. */
if (!defined('ABSPATH')) { exit; }

function dimp_policy_titles() {
    return array('privacy' => 'Privacy Policy', 'terms' => 'Terms & Conditions', 'refund' => 'Refund Policy');
}

function dimp_policy_options() {
    return array('privacy' => 'wp_page_for_privacy_policy', 'terms' => 'woocommerce_terms_page_id', 'refund' => 'dimp_refund_page_id');
}

function dimp_policy_page_url($name) {
    $options = dimp_policy_options();
    if (!isset($options[$name])) { return ''; }
    $id = (int) get_option($options[$name], 0);
    return $id > 0 && get_post_status($id) === 'publish' ? (string) get_permalink($id) : '';
}

/** Only trusted packaged policy files are read. Returns editor-friendly HTML. */
function dimp_policy_content($name) {
    $titles = dimp_policy_titles();
    if (!isset($titles[$name])) { return ''; }
    $file = get_template_directory() . '/views/' . $name . '.html';
    if (!is_readable($file)) { return ''; }
    $html = file_get_contents($file);
    if (!preg_match('~<article\b[^>]*data-policy-body[^>]*>(.*?)</article>~is', $html, $match)) { return ''; }
    return dimp_transform_html($match[1]);
}

function dimp_no_refund_notice() {
    $url = dimp_view_url('refund');
    echo '<p class="dimp-policy-note">Sales are final. No refunds for change of mind or customer-requested cancellation after payment. Read our <a href="' . esc_url($url) . '" target="_blank" rel="noopener noreferrer">Refund Policy</a>, including billing errors and rights under applicable law.</p>';
}
add_action('woocommerce_single_product_summary', 'dimp_no_refund_notice', 25);
add_action('woocommerce_review_order_before_submit', 'dimp_no_refund_notice', 8);
