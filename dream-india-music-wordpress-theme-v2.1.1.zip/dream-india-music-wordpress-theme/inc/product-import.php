<?php
/** Explicit, administrator-only WooCommerce setup for the bundled services. */
if (!defined('ABSPATH')) {
    exit;
}

function dimp_wc_import_result() {
    return array('success' => false, 'imported' => 0, 'skipped' => 0, 'failed' => 0, 'media_errors' => 0, 'pages' => array(), 'errors' => array());
}

/** Validate the complete local catalogue before any database or upload writes. */
function dimp_wc_catalogue_for_import() {
    $theme_dir = get_template_directory();
    $file = $theme_dir . '/assets/products.json';
    $image_root = realpath($theme_dir . '/assets/products');
    if (!$image_root || !is_readable($file)) {
        return new WP_Error('dimp_catalogue_missing', 'The bundled service catalogue or product images are missing. Reinstall the complete theme ZIP.');
    }
    $rows = json_decode(file_get_contents($file), true);
    if (!is_array($rows) || !$rows || count($rows) > 200 || array_keys($rows) !== range(0, count($rows) - 1)) {
        return new WP_Error('dimp_catalogue_invalid', 'The bundled service catalogue is invalid. No products were imported.');
    }
    $seen = array();
    $validated = array();
    foreach ($rows as $index => $row) {
        $label = 'Catalogue row ' . ($index + 1);
        if (!is_array($row) || !isset($row['sku'], $row['id'], $row['name'], $row['price'], $row['currency'], $row['category'], $row['description'], $row['unit'], $row['images']) ||
            !is_string($row['sku']) || !preg_match('/^DIP-[0-9]{3}$/D', $row['sku']) || isset($seen[$row['sku']]) ||
            !is_string($row['id']) || $row['id'] !== strtolower($row['sku']) ||
            !is_string($row['name']) || trim($row['name']) === '' || strlen($row['name']) > 600 ||
            !is_string($row['category']) || trim($row['category']) === '' || strlen($row['category']) > 200 ||
            !is_string($row['description']) || trim($row['description']) === '' || strlen($row['description']) > 20000 ||
            (!is_int($row['price']) && !is_float($row['price'])) || !is_finite((float) $row['price']) || $row['price'] < 0 || $row['price'] > 100000000 ||
            $row['currency'] !== 'INR' || !in_array($row['unit'], array('package', 'hour'), true) ||
            !is_array($row['images']) || !$row['images'] || count($row['images']) > 20) {
            return new WP_Error('dimp_catalogue_invalid', $label . ' has invalid service details. No products were imported.');
        }
        $seen[$row['sku']] = true;
        $row['_image_paths'] = array();
        foreach ($row['images'] as $relative) {
            if (!is_string($relative) || !preg_match('~^assets/products/dip-service-[0-9]{2}\.jpg$~D', $relative)) {
                return new WP_Error('dimp_image_invalid', $label . ' has an invalid image path. No products were imported.');
            }
            $absolute = realpath($theme_dir . '/' . $relative);
            if (!$absolute || strpos($absolute, $image_root . DIRECTORY_SEPARATOR) !== 0 || !is_file($absolute) || !is_readable($absolute)) {
                return new WP_Error('dimp_image_missing', $label . ' has a missing local image. No products were imported.');
            }
            $image_info = wp_getimagesize($absolute);
            if (!$image_info || empty($image_info['mime']) || $image_info['mime'] !== 'image/jpeg') {
                return new WP_Error('dimp_image_invalid', $label . ' has an invalid JPEG image. No products were imported.');
            }
            $row['_image_paths'][$relative] = $absolute;
        }
        $validated[] = $row;
    }
    return $validated;
}

/** Copy only the already-validated bundled image; never fetch remote URLs. */
function dimp_wc_import_image($relative, $absolute, $product_id, $title) {
    $existing = get_posts(array(
        'post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => 1,
        'fields' => 'ids', 'meta_key' => '_dimp_theme_image_source', 'meta_value' => $relative,
        'orderby' => 'ID', 'order' => 'ASC', 'no_found_rows' => true,
    ));
    if ($existing && wp_attachment_is_image($existing[0])) {
        $existing_file = get_attached_file($existing[0]);
        if ($existing_file && is_file($existing_file)) {
            return (int) $existing[0];
        }
    }
    $contents = file_get_contents($absolute);
    if ($contents === false || $contents === '') {
        return new WP_Error('dimp_image_read', 'Could not read the bundled product image.');
    }
    $upload = wp_upload_bits(basename($relative), null, $contents);
    if (!empty($upload['error'])) {
        return new WP_Error('dimp_image_upload', 'Could not copy the product image into the Media Library: ' . $upload['error']);
    }
    $attachment_id = wp_insert_attachment(array(
        'post_mime_type' => 'image/jpeg', 'post_title' => sanitize_text_field($title),
        'post_status' => 'inherit', 'post_content' => '', 'post_parent' => $product_id,
    ), $upload['file'], $product_id, true);
    if (is_wp_error($attachment_id)) {
        wp_delete_file($upload['file']);
        return $attachment_id;
    }
    update_post_meta($attachment_id, '_dimp_theme_image_source', $relative);
    update_post_meta($attachment_id, '_wp_attachment_image_alt', sanitize_text_field($title));
    // The original image remains usable if the host cannot generate smaller sizes.
    $metadata = wp_generate_attachment_metadata($attachment_id, $upload['file']);
    if (is_array($metadata) && $metadata) {
        wp_update_attachment_metadata($attachment_id, $metadata);
    }
    return (int) $attachment_id;
}

function dimp_wc_page_is_usable($page) {
    return $page instanceof WP_Post && $page->post_type === 'page' && !in_array($page->post_status, array('trash', 'auto-draft'), true);
}

/** Only reuse unconfigured pages when their content already belongs to WooCommerce. */
function dimp_wc_page_has_content($page, $role) {
    if (!dimp_wc_page_is_usable($page)) {
        return false;
    }
    $shortcodes = array('cart' => 'woocommerce_cart', 'checkout' => 'woocommerce_checkout', 'myaccount' => 'woocommerce_my_account', 'shop' => 'products');
    $blocks = array('cart' => 'woocommerce/cart', 'checkout' => 'woocommerce/checkout', 'myaccount' => 'woocommerce/my-account', 'shop' => 'woocommerce/product-collection');
    return has_shortcode($page->post_content, $shortcodes[$role]) || has_block($blocks[$role], $page->post_content) ||
        ($role === 'shop' && has_block('woocommerce/all-products', $page->post_content));
}

/** Preserve configured pages and every existing page's content. */
function dimp_wc_ensure_pages(&$errors, $prefer_classic = false) {
    $definitions = array(
        'shop' => array('title' => 'Shop', 'slug' => 'shop', 'content' => ''),
        'cart' => array('title' => 'Cart', 'slug' => 'cart', 'content' => '[woocommerce_cart]'),
        'checkout' => array('title' => 'Checkout', 'slug' => 'checkout', 'content' => '[woocommerce_checkout]'),
        'myaccount' => array('title' => 'My Account', 'slug' => 'my-account', 'content' => '[woocommerce_my_account]'),
    );
    $pages = array();
    foreach ($definitions as $role => $definition) {
        $option = 'woocommerce_' . $role . '_page_id';
        $configured_id = (int) get_option($option, 0);
        $configured = $configured_id > 0 ? get_post($configured_id) : null;
        $classic_shortcode = $role === 'cart' ? 'woocommerce_cart' : 'woocommerce_checkout';
        $must_use_classic = $prefer_classic === true && in_array($role, array('cart', 'checkout'), true);
        if (dimp_wc_page_is_usable($configured) && (!$must_use_classic || ($configured->post_status === 'publish' && has_shortcode($configured->post_content, $classic_shortcode)))) {
            $pages[$role] = (int) $configured->ID;
            continue;
        }
        $candidate = null;
        if ($must_use_classic) {
            $owned_pages = get_posts(array(
                'post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => -1,
                'meta_key' => '_dimp_commerce_page', 'meta_value' => $role,
                'orderby' => 'ID', 'order' => 'ASC', 'no_found_rows' => true,
            ));
            foreach ($owned_pages as $owned_page) {
                if (has_shortcode($owned_page->post_content, $classic_shortcode)) {
                    $candidate = $owned_page;
                    break;
                }
            }
        } else {
            $candidate = get_page_by_path($definition['slug'], OBJECT, 'page');
        }
        if (dimp_wc_page_has_content($candidate, $role) && (!$must_use_classic || ($candidate->post_status === 'publish' && has_shortcode($candidate->post_content, $classic_shortcode)))) {
            $page_id = (int) $candidate->ID;
        } else {
            $page_id = wp_insert_post(array(
                'post_type' => 'page', 'post_status' => 'publish',
                'post_title' => $definition['title'], 'post_name' => $must_use_classic ? $role . '-classic' : $definition['slug'],
                'post_content' => $definition['content'], 'post_author' => get_current_user_id(),
                'comment_status' => 'closed', 'ping_status' => 'closed',
                'meta_input' => array('_dimp_commerce_page' => $role),
            ), true);
            if (is_wp_error($page_id) || !$page_id) {
                $errors[] = 'Could not create the ' . $definition['title'] . ' page. Create it in WooCommerce settings.';
                continue;
            }
        }
        update_option($option, (int) $page_id);
        $pages[$role] = (int) $page_id;
    }
    return $pages;
}

/** Create native editable policies only during the explicit store setup action. */
function dimp_wc_ensure_policy_pages(&$errors) {
    if (!function_exists('dimp_policy_content') || !function_exists('dimp_policy_titles')) {
        $errors[] = 'The bundled policy templates are missing. Reinstall the complete theme ZIP before creating legal pages.';
        return array();
    }
    $titles = dimp_policy_titles();
    $definitions = array(
        'privacy' => array('option' => 'wp_page_for_privacy_policy', 'slug' => 'privacy-policy'),
        'terms' => array('option' => 'woocommerce_terms_page_id', 'slug' => 'terms-and-conditions'),
        'refund' => array('option' => 'dimp_refund_page_id', 'slug' => 'refund-policy'),
    );
    $pages = array();
    $created = array();
    foreach ($definitions as $role => $definition) {
        $configured_id = (int) get_option($definition['option'], 0);
        $configured = $configured_id > 0 ? get_post($configured_id) : null;
        if (dimp_wc_page_is_usable($configured) && $configured->post_status === 'publish') {
            $pages[$role] = (int) $configured->ID;
            continue;
        }
        $candidate = get_page_by_path($definition['slug'], OBJECT, 'page');
        if (dimp_wc_page_is_usable($candidate) && $candidate->post_status === 'publish' && strlen(trim(wp_strip_all_tags($candidate->post_content))) >= 80) {
            $page_id = (int) $candidate->ID;
        } else {
            $title = isset($titles[$role]) && is_string($titles[$role]) ? $titles[$role] : ucfirst($role) . ' Policy';
            $page_id = wp_insert_post(array(
                'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $title,
                'post_name' => $definition['slug'], 'post_content' => '',
                'post_author' => get_current_user_id(), 'comment_status' => 'closed',
                'ping_status' => 'closed', 'meta_input' => array('_dimp_policy_page' => $role),
            ), true);
            if (is_wp_error($page_id) || !$page_id) {
                $errors[] = 'Could not create the ' . $role . ' policy page. Create and assign it in WordPress settings.';
                continue;
            }
            $created[$role] = (int) $page_id;
        }
        update_option($definition['option'], (int) $page_id);
        $pages[$role] = (int) $page_id;
    }
    // All option IDs now exist, so cross-links in the HTML resolve to native pages.
    foreach ($created as $role => $page_id) {
        $body = dimp_policy_content($role);
        if (!is_string($body) || trim(wp_strip_all_tags($body)) === '') {
            $errors[] = 'The ' . $role . ' policy text is missing. Edit its new page before accepting orders.';
            continue;
        }
        $updated = wp_update_post(array('ID' => $page_id, 'post_content' => wp_kses_post($body)), true);
        if (is_wp_error($updated) || !$updated) {
            $errors[] = 'Could not save the ' . $role . ' policy text. Edit its new page before accepting orders.';
        }
    }
    return $pages;
}

/**
 * Public PHP entry point, deliberately guarded as well as the POST handler.
 * It runs only after an administrator explicitly requests an import.
 */
function dimp_wc_import_services($prefer_classic = false) {
    $result = dimp_wc_import_result();
    if (!current_user_can('manage_options') || !current_user_can('manage_woocommerce')) {
        $result['errors'][] = 'Only an administrator with WooCommerce management access can import services.';
        return $result;
    }
    if (!class_exists('WooCommerce') || !class_exists('WC_Product_Simple') || !function_exists('wc_get_product_id_by_sku')) {
        $result['errors'][] = 'Install and activate WooCommerce before importing services.';
        return $result;
    }
    if (get_option('woocommerce_currency') !== 'INR') {
        $result['errors'][] = 'The supplied prices are in Indian rupees. Set WooCommerce currency to Indian rupee (INR), then run the import. No prices or currency settings were changed.';
        return $result;
    }
    $catalogue = dimp_wc_catalogue_for_import();
    if (is_wp_error($catalogue)) {
        $result['errors'][] = $catalogue->get_error_message();
        return $result;
    }
    $lock_name = '_dimp_service_import_lock';
    $lock = get_option($lock_name);
    if (is_array($lock) && isset($lock['time']) && (int) $lock['time'] < time() - 600) {
        delete_option($lock_name);
    }
    if (!add_option($lock_name, array('time' => time(), 'user' => get_current_user_id()), '', false)) {
        $result['errors'][] = 'A service import is already running. Please wait for it to finish before trying again.';
        return $result;
    }
    try {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $categories = array();
        foreach ($catalogue as $row) {
            if (wc_get_product_id_by_sku($row['sku'])) {
                $result['skipped']++;
                continue;
            }
            try {
                if (!isset($categories[$row['category']])) {
                    $term = term_exists($row['category'], 'product_cat');
                    if (!$term) {
                        $term = wp_insert_term($row['category'], 'product_cat');
                    }
                    if (is_wp_error($term)) {
                        throw new Exception('Could not create its product category.');
                    }
                    $categories[$row['category']] = (int) (is_array($term) ? $term['term_id'] : $term);
                }
                $product = new WC_Product_Simple();
                $product->set_name(sanitize_text_field($row['name']));
                $product->set_sku($row['sku']);
                $product->set_status('publish');
                $product->set_catalog_visibility('visible');
                $product->set_virtual(true);
                $product->set_downloadable(false);
                $product->set_manage_stock(false);
                $product->set_stock_status('instock');
                $product->set_regular_price(wc_format_decimal($row['price'], wc_get_price_decimals()));
                $product->set_description(wpautop(esc_html($row['description'])));
                $short = $row['unit'] === 'hour' ? 'Price is for one hour. Quantity 1 = one hour; quantity 2 = two hours. Contact the studio to confirm session availability.' : 'One quantity is one service package. Contact the studio to confirm the schedule and package details.';
                $product->set_short_description($short);
                $product->set_category_ids(array($categories[$row['category']]));
                $product->update_meta_data('_dimp_catalog_id', $row['id']);
                $product->update_meta_data('_dip_unit', $row['unit']);
                $product->update_meta_data('_dimp_import_version', '2.1.0');
                $product_id = $product->save();
                if (!$product_id) {
                    throw new Exception('WooCommerce could not save the product.');
                }
                $result['imported']++;
            } catch (Throwable $error) {
                $result['failed']++;
                $result['errors'][] = $row['sku'] . ': ' . sanitize_text_field($error->getMessage());
                continue;
            }
            $image_ids = array();
            foreach ($row['_image_paths'] as $relative => $absolute) {
                try {
                    $attachment_id = dimp_wc_import_image($relative, $absolute, $product_id, $row['name']);
                    if (is_wp_error($attachment_id)) {
                        throw new Exception($attachment_id->get_error_message());
                    }
                    $image_ids[] = $attachment_id;
                } catch (Throwable $error) {
                    $result['media_errors']++;
                    $result['errors'][] = $row['sku'] . ': product saved; image needs attention. ' . sanitize_text_field($error->getMessage());
                }
            }
            if ($image_ids) {
                try {
                    $product->set_image_id(array_shift($image_ids));
                    $product->set_gallery_image_ids(array_values(array_unique($image_ids)));
                    $product->save();
                } catch (Throwable $error) {
                    $result['media_errors']++;
                    $result['errors'][] = $row['sku'] . ': product saved; assign its Media Library image in Products.';
                }
            }
        }
        $page_errors = array();
        $result['pages'] = array_merge(dimp_wc_ensure_pages($page_errors, $prefer_classic), dimp_wc_ensure_policy_pages($page_errors));
        $result['errors'] = array_merge($result['errors'], $page_errors);
        // This is an explicit setup action, never an activation or per-request write.
        flush_rewrite_rules(false);
        $result['success'] = $result['failed'] === 0 && count($result['pages']) === 7 && !$page_errors;
    } catch (Throwable $error) {
        $result['errors'][] = 'Import stopped: ' . sanitize_text_field($error->getMessage()) . ' Saved products remain available; you can run the import again.';
    } finally {
        delete_option($lock_name);
    }
    return $result;
}

function dimp_wc_import_services_post() {
    if (!isset($_SERVER['REQUEST_METHOD']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
        wp_die('Please use the Import services button on the Shop & Payments settings page.', '', array('response' => 405));
    }
    if (!current_user_can('manage_options') || !current_user_can('manage_woocommerce')) {
        wp_die('You do not have permission to import services.', '', array('response' => 403));
    }
    check_admin_referer('dimp_import_services');
    $prefer_classic = isset($_POST['use_classic']) && is_string($_POST['use_classic']) && $_POST['use_classic'] === '1';
    $result = dimp_wc_import_services($prefer_classic);
    set_transient('dimp_import_result_' . get_current_user_id(), $result, 10 * MINUTE_IN_SECONDS);
    wp_safe_redirect(admin_url('themes.php?page=dimp-shop-payments'));
    exit;
}
add_action('admin_post_dimp_import_services', 'dimp_wc_import_services_post');

function dimp_wc_setup_menu() {
    add_theme_page('Shop & Payments', 'Shop & Payments', 'manage_options', 'dimp-shop-payments', 'dimp_wc_setup_page');
}
add_action('admin_menu', 'dimp_wc_setup_menu');

function dimp_wc_setup_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    $active = class_exists('WooCommerce') && class_exists('WC_Product_Simple');
    $currency = get_option('woocommerce_currency', '');
    $allowed = $active && current_user_can('manage_woocommerce') && $currency === 'INR';
    $result_key = 'dimp_import_result_' . get_current_user_id();
    $result = get_transient($result_key);
    if ($result) {
        delete_transient($result_key);
    }
    ?>
    <div class="wrap">
        <h1>Dream India — Shop &amp; Payments</h1>
        <p>Use WooCommerce for products, cart, checkout and orders, and Razorpay for UPI, cards and netbanking.</p>
        <?php if (is_array($result)) : ?>
            <div class="notice <?php echo !empty($result['success']) && empty($result['media_errors']) ? 'notice-success' : 'notice-warning'; ?>"><p>
                <?php echo esc_html(sprintf('Services imported: %d. Existing SKUs skipped: %d. Products failed: %d. Image warnings: %d.', $result['imported'], $result['skipped'], $result['failed'], $result['media_errors'])); ?>
            </p><?php if (!empty($result['errors'])) : ?><ul><?php foreach ($result['errors'] as $error) : ?><li><?php echo esc_html($error); ?></li><?php endforeach; ?></ul><?php endif; ?></div>
        <?php endif; ?>
        <h2>1. Install WooCommerce and set Indian rupees</h2>
        <p><a class="button" href="<?php echo esc_url(admin_url('plugin-install.php?s=woocommerce&tab=search&type=term')); ?>">Find WooCommerce</a> Install the official WooCommerce plugin by Automattic, activate it and complete its store setup.</p>
        <p>Open <a href="<?php echo esc_url(admin_url('admin.php?page=wc-settings')); ?>">WooCommerce → Settings → General</a> and set Currency to <strong>Indian rupee (INR)</strong>. Enter your actual business address and review tax settings.</p>
        <p><strong>Current status:</strong> <?php echo $active ? 'WooCommerce active.' : 'WooCommerce is not active.'; ?> Currency: <?php echo esc_html($currency ?: 'not configured'); ?>.</p>
        <h2>2. Import the 25 services and create missing store pages</h2>
        <p>This copies the bundled names, INR prices, descriptions and local images to Products. Services are virtual, so shipping is not required. Hourly services use one cart quantity per hour.</p>
        <p>Existing products with the same SKU are skipped. Existing page content is never overwritten or deleted. Missing Shop, Cart, Checkout and My Account pages are created. With the classic option below selected, existing block or custom Cart/Checkout pages are kept and new classic pages are assigned for Razorpay compatibility.</p>
        <p>The setup also creates editable Privacy, Terms and Refund pages if needed, assigns the WordPress privacy page and WooCommerce Terms page, and links them in your store. Review these pages in Pages before accepting orders, including your business contact details and refund terms.</p>
        <p><strong>Review prices before selling:</strong> catalogue items priced at ₹0 will be free at checkout. Update those prices in Products if payment is required.</p>
        <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post">
            <input type="hidden" name="action" value="dimp_import_services">
            <?php wp_nonce_field('dimp_import_services'); ?>
            <p><label><input type="checkbox" name="use_classic" value="1" checked> Use classic cart and checkout for Razorpay (keeps existing pages)</label></p>
            <?php submit_button('Import services and create missing store pages', 'primary', 'submit', false, $allowed ? array() : array('disabled' => 'disabled')); ?>
        </form>
        <?php if (!$allowed) : ?><p>Activate WooCommerce, use an administrator account with WooCommerce access and set INR to enable this button.</p><?php endif; ?>
        <h2>3. Connect Razorpay</h2>
        <ol>
            <li>Install and activate <a href="<?php echo esc_url(admin_url('plugin-install.php?s=razorpay&tab=search&type=term')); ?>">Razorpay for WooCommerce</a>, the official plugin by Razorpay.</li>
            <li>In <strong>WooCommerce → Settings → Payments → Razorpay</strong>, enable the gateway and enter your Razorpay Test Key ID and Test Key Secret from your Razorpay dashboard. Keep keys in your secure WordPress settings; do not send them in chat.</li>
            <li>Follow the Razorpay plugin's webhook instructions and use its provided webhook URL and signing secret. Leave order status and signature verification to the official gateway plugin.</li>
            <li>Use Razorpay Test Mode to place a test order from Shop through Cart and Checkout. Check that its payment and order status update in WooCommerce → Orders.</li>
            <li>After Razorpay approves your account and live payments, switch to Live Mode and enter your Live keys. Available UPI, card and netbanking methods depend on your Razorpay account settings.</li>
        </ol>
        <p>The theme does not store gateway keys or collect card details. Installing or importing services does not enable a payment gateway or charge a customer.</p>
        <p><a class="button" href="<?php echo esc_url(admin_url('edit.php?post_type=product')); ?>">Manage products and prices</a> <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wc-settings&tab=checkout')); ?>">Payment settings</a> <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wc-settings&tab=advanced')); ?>">Store page settings</a></p>
    </div>
    <?php
}
