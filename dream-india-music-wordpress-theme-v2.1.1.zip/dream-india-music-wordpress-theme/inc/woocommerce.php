<?php
/** Optional WooCommerce shop, cart and checkout integration. */
if (!defined('ABSPATH')) {
    exit;
}

function dimp_wc_is_active() {
    return class_exists('WooCommerce') && function_exists('WC');
}

function dimp_wc_support() {
    add_theme_support('woocommerce', array(
        'thumbnail_image_width' => 440,
        'single_image_width' => 720,
        'product_grid' => array('default_rows' => 4, 'min_rows' => 1, 'default_columns' => 3, 'min_columns' => 1, 'max_columns' => 4),
    ));
    add_theme_support('wc-product-gallery-zoom');
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
}
add_action('after_setup_theme', 'dimp_wc_support');

function dimp_wc_body_classes($classes) {
    if (dimp_wc_is_active() && !in_array('woocommerce-active', $classes, true)) {
        $classes[] = 'woocommerce-active';
    }
    return $classes;
}
add_filter('body_class', 'dimp_wc_body_classes');

function dimp_wc_is_page() {
    return dimp_wc_is_active() && (
        (function_exists('is_woocommerce') && is_woocommerce()) ||
        (function_exists('is_cart') && is_cart()) ||
        (function_exists('is_checkout') && is_checkout()) ||
        (function_exists('is_account_page') && is_account_page())
    );
}

function dimp_wc_page_url($name) {
    if (!dimp_wc_is_active() || !function_exists('wc_get_page_id')) {
        return '';
    }
    $id = wc_get_page_id($name);
    if ($id <= 0 || get_post_status($id) !== 'publish') {
        return '';
    }
    return (string) get_permalink($id);
}

function dimp_wc_shop_url() {
    return dimp_wc_page_url('shop');
}

function dimp_wc_product_id($value) {
    if (!dimp_wc_is_active() || !is_string($value) || !preg_match('/\Adip-[0-9]{3}\z/i', $value)) {
        return 0;
    }
    return (int) wc_get_product_id_by_sku(strtoupper($value));
}

/** Empty means the original enquiry shop can still handle this link. */
function dimp_wc_resolve_view_url($view, $args = array()) {
    $policy = dimp_policy_page_url($view);
    if ($policy) {
        return $args ? add_query_arg($args, $policy) : $policy;
    }
    if (!dimp_wc_is_active()) {
        return '';
    }
    if ($view === 'shop') {
        $url = dimp_wc_shop_url();
        return $url && $args ? add_query_arg($args, $url) : $url;
    }
    if ($view === 'product' && isset($args['id'])) {
        $id = dimp_wc_product_id($args['id']);
        if ($id && get_post_status($id) === 'publish') {
            unset($args['id']);
            $url = get_permalink($id);
            return $args ? add_query_arg($args, $url) : $url;
        }
    }
    return '';
}

/** Retain old service bookmarks after WooCommerce setup. */
function dimp_wc_legacy_redirect() {
    if (!dimp_wc_is_active()) {
        return;
    }
    $view = get_query_var('dip_view', '');
    if ($view === 'shop') {
        $target = dimp_wc_shop_url();
    } elseif ($view === 'product') {
        $value = isset($_GET['id']) && is_string($_GET['id']) ? sanitize_text_field(wp_unslash($_GET['id'])) : '';
        $id = dimp_wc_product_id($value);
        $target = $id && get_post_status($id) === 'publish' ? get_permalink($id) : dimp_wc_shop_url();
    } else {
        return;
    }
    if (!empty($target)) {
        wp_safe_redirect($target, 302, 'Dream India Shop');
        exit;
    }
}
add_action('template_redirect', 'dimp_wc_legacy_redirect', 0);

function dimp_wc_cart_link() {
    $url = dimp_wc_page_url('cart');
    if (!$url) {
        return '';
    }
    $count = WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
    return '<a class="dimp-cart-link" href="' . esc_url($url) . '">Cart <span class="dimp-cart-count">' . esc_html($count) . '</span></a>';
}

function dimp_wc_navigation($header) {
    if (!dimp_wc_is_active() || !dimp_wc_shop_url()) {
        return $header;
    }
    if (dimp_wc_is_page()) {
        $header = preg_replace('~\s+aria-current=[\'\"]page[\'\"]~i', '', $header);
        $header = str_replace('href="shop.html"', 'href="shop.html" aria-current="page"', $header);
    }
    $links = dimp_wc_cart_link();
    $account = dimp_wc_page_url('myaccount');
    if ($account) {
        $links .= '<a class="dimp-account-link" href="' . esc_url($account) . '">My Account</a>';
    }
    return str_replace('</nav>', $links . '</nav>', $header);
}
add_filter('dimp_header_html', 'dimp_wc_navigation');

function dimp_wc_cart_fragments($fragments) {
    $link = dimp_wc_cart_link();
    if ($link) {
        $fragments['a.dimp-cart-link'] = $link;
    }
    return $fragments;
}
add_filter('woocommerce_add_to_cart_fragments', 'dimp_wc_cart_fragments');

function dimp_wc_assets() {
    if (dimp_wc_is_active() && dimp_wc_page_url('cart')) {
        wp_enqueue_script('wc-cart-fragments');
    }
}
add_action('wp_enqueue_scripts', 'dimp_wc_assets', 30);

function dimp_wc_thumbnail_size($size) {
    // Posters contain service details and prices: keep the entire image visible.
    return array('width' => 440, 'height' => 0, 'crop' => false);
}
add_filter('woocommerce_get_image_size_thumbnail', 'dimp_wc_thumbnail_size');

function dimp_wc_price_unit($html, $product) {
    if ($product && $product->get_meta('_dip_unit') === 'hour') {
        $html .= ' <small class="dimp-price-unit">/ hour</small>';
    }
    return $html;
}
add_filter('woocommerce_get_price_html', 'dimp_wc_price_unit', 20, 2);

function dimp_wc_item_unit($data, $item) {
    if (!empty($item['data']) && $item['data']->get_meta('_dip_unit') === 'hour') {
        $data[] = array('key' => 'Billing unit', 'value' => '1 hour per quantity');
    }
    return $data;
}
add_filter('woocommerce_get_item_data', 'dimp_wc_item_unit', 10, 2);

function dimp_wc_order_unit($item, $key, $values, $order) {
    if (!empty($values['data']) && $values['data']->get_meta('_dip_unit') === 'hour') {
        $item->add_meta_data('Billing unit', '1 hour per quantity', true);
    }
}
add_action('woocommerce_checkout_create_order_line_item', 'dimp_wc_order_unit', 10, 4);
