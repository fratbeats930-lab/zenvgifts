<?php
if (!defined('ABSPATH')) { exit; }
get_header();
dimp_render_part('main', 'index');
get_footer();
