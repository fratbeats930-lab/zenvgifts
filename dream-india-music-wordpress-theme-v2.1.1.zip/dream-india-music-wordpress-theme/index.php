<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<main id="dimp-content" class="dimp-entry" tabindex="-1">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <article <?php post_class(); ?> id="post-<?php the_ID(); ?>">
            <h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
            <div class="dimp-entry-content"><?php the_content(); wp_link_pages(); ?></div>
        </article>
    <?php endwhile; the_posts_pagination(); else : ?>
        <h1><?php esc_html_e('Welcome to Dream India Production', 'dream-india-music-wordpress-theme'); ?></h1>
        <p><a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Explore the studio website', 'dream-india-music-wordpress-theme'); ?></a></p>
    <?php endif; ?>
</main>
<?php get_footer(); ?>
