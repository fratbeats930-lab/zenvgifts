<?php
/** WordPress integration for the Dream India music website. */
if (!defined('ABSPATH')) {
    exit;
}

define('DIMP_THEME_VERSION', '2.1.1');
define('DIMP_AUDITION_URL', 'https://dreamindiaproduction.online/');

require_once get_template_directory() . '/inc/policies.php';
require_once get_template_directory() . '/inc/woocommerce.php';
require_once get_template_directory() . '/inc/product-import.php';

function dimp_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('responsive-embeds');
    add_theme_support('html5', array('search-form', 'gallery', 'caption', 'style', 'script'));
    add_theme_support('custom-logo', array('height' => 130, 'width' => 260, 'flex-width' => true, 'flex-height' => true));
    load_theme_textdomain('dream-india-music-wordpress-theme', get_template_directory() . '/languages');
}
add_action('after_setup_theme', 'dimp_setup');

function dimp_view_names() {
    return array('index', 'about', 'services', 'shop', 'product', 'our-songs', 'gallery', 'contact', 'privacy', 'terms', 'refund');
}

function dimp_view_name() {
    if (dimp_wc_is_page()) {
        return '';
    }
    $view = get_query_var('dip_view', '');
    if (!is_string($view)) {
        return '';
    }
    $view = sanitize_key($view);
    if ($view === 'catalogue') {
        return 'our-songs';
    }
    if (in_array($view, dimp_view_names(), true)) {
        return $view;
    }
    if ($view !== '') {
        return '';
    }
    return is_front_page() ? 'index' : '';
}

function dimp_query_vars($vars) {
    $vars[] = 'dip_view';
    return $vars;
}
add_filter('query_vars', 'dimp_query_vars');

function dimp_view_url($view = 'index', $args = array()) {
    $commerce = dimp_wc_resolve_view_url($view, $args);
    if ($commerce !== '') {
        return $commerce;
    }
    $url = home_url('/');
    if ($view !== 'index') {
        $args = array_merge(array('dip_view' => $view), $args);
    }
    return $args ? add_query_arg($args, $url) : $url;
}

function dimp_virtual_template($template) {
    if (get_query_var('dip_view') && dimp_view_name()) {
        return get_template_directory() . '/view.php';
    }
    return $template;
}
add_filter('template_include', 'dimp_virtual_template', 99);

function dimp_virtual_status() {
    if (get_query_var('dip_view') && dimp_view_name()) {
        global $wp_query;
        $wp_query->is_404 = false;
        status_header(200);
    }
}
add_action('template_redirect', 'dimp_virtual_status', 1);

function dimp_canonical_redirect($redirect) {
    return get_query_var('dip_view') && dimp_view_name() ? false : $redirect;
}
add_filter('redirect_canonical', 'dimp_canonical_redirect');

function dimp_settings() {
    $settings = get_option('dimp_settings', array());
    return is_array($settings) ? $settings : array();
}

function dimp_audition_url() {
    $settings = dimp_settings();
    return !empty($settings['audition_url']) ? $settings['audition_url'] : DIMP_AUDITION_URL;
}

function dimp_social_labels() {
    return array('youtube' => 'YouTube', 'instagram' => 'Instagram', 'facebook' => 'Facebook', 'spotify' => 'Spotify', 'x' => 'X');
}

function dimp_social_data() {
    $settings = dimp_settings();
    $socials = array();
    foreach (dimp_social_labels() as $key => $label) {
        if (!empty($settings[$key])) {
            $socials[] = array('label' => $label, 'url' => $settings[$key]);
        }
    }
    return $socials;
}

function dimp_assets() {
    $base = get_template_directory_uri() . '/assets/';
    wp_enqueue_style('dimp-music', $base . 'style.css', array(), DIMP_THEME_VERSION);
    wp_enqueue_style('dimp-theme', get_stylesheet_uri(), array('dimp-music'), DIMP_THEME_VERSION);
    if (dimp_wc_is_active()) {
        wp_enqueue_style('dimp-commerce', $base . 'commerce.css', array('dimp-theme'), DIMP_THEME_VERSION);
    }
    wp_enqueue_script('dimp-app', $base . 'app.js', array(), DIMP_THEME_VERSION, true);
    wp_enqueue_script('dimp-media', $base . 'media.js', array(), DIMP_THEME_VERSION, true);
    wp_localize_script('dimp-media', 'dipMediaConfig', array('songsUrl' => add_query_arg('ver', DIMP_THEME_VERSION, $base . 'songs.json'), 'socialsUrl' => $base . 'social-links.json', 'socialsData' => dimp_social_data()));
    if (in_array(dimp_view_name(), array('shop', 'product'), true)) {
        wp_enqueue_script('dimp-shop', $base . 'shop.js', array(), DIMP_THEME_VERSION, true);
        wp_localize_script('dimp-shop', 'dipShopConfig', array('productsUrl' => $base . 'products.json', 'assetBase' => get_template_directory_uri() . '/', 'productUrl' => dimp_view_url('product')));
    }
}
add_action('wp_enqueue_scripts', 'dimp_assets');

/** Source pages are packaged with the theme; visitors cannot choose file paths. */
function dimp_source($view = '') {
    static $cache = array();
    $view = $view ?: dimp_view_name();
    if (!in_array($view, dimp_view_names(), true)) {
        $view = 'index';
    }
    if (!isset($cache[$view])) {
        $file = get_template_directory() . '/views/' . $view . '.html';
        $cache[$view] = is_readable($file) ? file_get_contents($file) : '';
    }
    return $cache[$view];
}

function dimp_transform_url($url) {
    $url = html_entity_decode($url, ENT_QUOTES, 'UTF-8');
    if (rtrim($url, '/') === rtrim(DIMP_AUDITION_URL, '/')) {
        return dimp_audition_url();
    }
    if ($url === '' || preg_match('~^(?:[a-z][a-z0-9+.-]*:|//|\#|/)~i', $url)) {
        return $url;
    }
    if (strpos($url, 'assets/') === 0) {
        return get_template_directory_uri() . '/' . $url;
    }
    $parts = wp_parse_url($url);
    if (!$parts || empty($parts['path'])) {
        return $url;
    }
    $view = preg_replace('/\.html$/', '', basename($parts['path']));
    if ($view === 'catalogue') {
        $view = 'our-songs';
    }
    if (!in_array($view, dimp_view_names(), true)) {
        return $url;
    }
    $args = array();
    if (!empty($parts['query'])) {
        wp_parse_str($parts['query'], $args);
        unset($args['dip_view']);
    }
    $result = dimp_view_url($view, $args);
    return !empty($parts['fragment']) ? $result . '#' . $parts['fragment'] : $result;
}

function dimp_transform_html($html) {
    $html = preg_replace_callback('~\b(href|src|poster|action)\s*=\s*([\'\"])(.*?)\2~i', function ($match) {
        return $match[1] . '=' . $match[2] . esc_url(dimp_transform_url($match[3])) . $match[2];
    }, $html);
    return $html;
}

function dimp_render_part($part, $view = '') {
    $source = dimp_source($view);
    if ($part === 'header' && preg_match('~<header\b[^>]*>.*?</header>~is', $source, $match)) {
        echo dimp_transform_html(apply_filters('dimp_header_html', $match[0])); // Trusted theme HTML; dynamic URLs are escaped above.
    } elseif ($part === 'main' && preg_match('~<main\b[^>]*>.*?</main>~is', $source, $match)) {
        $main = preg_replace('~<main\b~i', '<main id="dimp-content" tabindex="-1"', $match[0], 1);
        echo dimp_transform_html($main);
    } elseif ($part === 'footer' && preg_match('~(<footer\b[^>]*>.*?</footer>)(.*?)<script\b~is', $source, $match)) {
        $footer = preg_replace('~©\s*\d{4}~u', '© ' . esc_html(wp_date('Y')), $match[1] . $match[2]);
        echo dimp_transform_html($footer);
    }
}

function dimp_document_title($title) {
    if (dimp_view_name() && preg_match('~<title>(.*?)</title>~is', dimp_source(), $match)) {
        return html_entity_decode($match[1], ENT_QUOTES, 'UTF-8');
    }
    return $title;
}
add_filter('pre_get_document_title', 'dimp_document_title');

function dimp_head_meta() {
    echo '<meta name="theme-color" content="#000000">';
    if (dimp_view_name() && preg_match('~<meta\s+name="description"\s+content="([^"]*)"~i', dimp_source(), $match)) {
        echo '<meta name="description" content="' . esc_attr(html_entity_decode($match[1], ENT_QUOTES, 'UTF-8')) . '">';
    }
    if (get_query_var('dip_view') && dimp_view_name()) {
        echo '<link rel="canonical" href="' . esc_url(dimp_view_url(dimp_view_name())) . '">';
    }
}
add_action('wp_head', 'dimp_head_meta', 3);

function dimp_sanitize_settings($input) {
    $old = dimp_settings();
    $clean = array();
    $fields = array_merge(array('audition_url' => 'Audition Registration'), dimp_social_labels());
    foreach ($fields as $key => $label) {
        $value = isset($input[$key]) && is_string($input[$key]) ? trim($input[$key]) : '';
        if ($value === '') {
            $clean[$key] = '';
            continue;
        }
        $url = esc_url_raw($value, array('https'));
        $parts = wp_parse_url($url);
        if (!$url || !$parts || empty($parts['host']) || empty($parts['scheme']) || $parts['scheme'] !== 'https' || isset($parts['user']) || isset($parts['pass'])) {
            add_settings_error('dimp_settings', 'invalid_' . $key, $label . ': enter a complete HTTPS URL. The previous value was kept.');
            $clean[$key] = isset($old[$key]) ? $old[$key] : '';
        } else {
            $clean[$key] = $url;
        }
    }
    return $clean;
}

function dimp_register_settings() {
    register_setting('dimp_settings_group', 'dimp_settings', array('type' => 'array', 'sanitize_callback' => 'dimp_sanitize_settings'));
}
add_action('admin_init', 'dimp_register_settings');

function dimp_settings_menu() {
    add_theme_page('Dream India Settings', 'Dream India Settings', 'manage_options', 'dimp-settings', 'dimp_settings_page');
}
add_action('admin_menu', 'dimp_settings_menu');

function dimp_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    $settings = dimp_settings();
    ?>
    <div class="wrap"><h1>Dream India Production — Website Settings</h1>
    <p>Our Songs is included on the homepage and on its own page. Song previews use the supplied YouTube links.</p>
    <?php settings_errors(); ?>
    <form action="options.php" method="post"><?php settings_fields('dimp_settings_group'); ?>
        <table class="form-table" role="presentation">
            <tr><th scope="row"><label for="dimp-audition">Audition Registration URL</label></th><td><input type="url" class="large-text" id="dimp-audition" name="dimp_settings[audition_url]" value="<?php echo esc_attr(isset($settings['audition_url']) ? $settings['audition_url'] : DIMP_AUDITION_URL); ?>"><p class="description">The homepage button links to your existing audition registration website. Paste a different HTTPS URL here if needed.</p></td></tr>
            <?php foreach (dimp_social_labels() as $key => $label) : ?>
                <tr><th scope="row"><label for="dimp-<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></label></th><td><input type="url" class="large-text" id="dimp-<?php echo esc_attr($key); ?>" name="dimp_settings[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr(isset($settings[$key]) ? $settings[$key] : ''); ?>"><p class="description">Paste your public HTTPS profile or channel URL, or leave empty.</p></td></tr>
            <?php endforeach; ?>
        </table><?php submit_button(); ?>
    </form>
    <p><a href="<?php echo esc_url(dimp_view_url('our-songs')); ?>">View Our Songs</a> · <a href="<?php echo esc_url(dimp_audition_url()); ?>" target="_blank" rel="noopener noreferrer">Open audition registration website</a></p>
    </div>
    <?php
}
