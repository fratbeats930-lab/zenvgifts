<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<main id="dimp-content" class="dimp-commerce-shell" tabindex="-1">
    <?php woocommerce_content(); ?>
</main>
<?php get_footer(); ?>
