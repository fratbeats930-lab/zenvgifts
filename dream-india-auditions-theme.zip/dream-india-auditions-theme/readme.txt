=== Dream India Auditions ===
Version: 1.2.0
Requires at least: 6.0
Requires PHP: 7.4
License: GPLv2 or later

An installable classic WordPress THEME for the Dream India Production audition website.

Upload dream-india-auditions-theme.zip at Appearance > Themes > Add New > Upload Theme.
Activate the theme. The audition registration website appears automatically on the home page.
No separate plugin is required. Existing dip_* settings and private entries are retained.

Configure the Google Sheets endpoint and shared secret at Settings > Dream India Auditions.
Full Hindi instructions are in SETUP-HINDI.txt. Apps Script source is google-apps-script.gs.

Registration remains closed until the Google endpoint and shared secret are configured.
Valid submissions are backed up privately under Audition Entries before Google Sheets sync.
Temporary sync failures remain pending and retry hourly via WordPress cron, which requires site traffic or a server cron trigger.
The [dream_india_audition] shortcode and Audition Registration page template are also available.

Changing themes does not erase registration records or settings. Re-enable this theme or the
original Dream India Audition Registration plugin to access them again. Do not delete the old plugin's data.

1.2.0: Converted original plugin website to a proper standalone theme with style.css,
index.php, theme lifecycle hooks, early asset loading, compatible private registration
backend, accessible form feedback and a compressed WebP illustration.
