<?php
if (!defined('ABSPATH')) { exit; }
get_header();
while (have_posts()) : the_post();
    $has_form = has_shortcode(get_the_content(), 'dream_india_audition');
    ?>
    <div id="dia-content" tabindex="-1"<?php if (!$has_form) { echo ' class="dia-content-shell"'; } ?>>
        <?php if (!$has_form) : ?>
            <nav class="dia-page-brand" aria-label="Home"><a href="<?php echo esc_url(home_url('/')); ?>">Dream India Production</a><a href="<?php echo esc_url(home_url('/')); ?>">Audition Registration ↗</a></nav>
            <h1><?php the_title(); ?></h1>
        <?php endif; ?>
        <div class="dia-entry-content"><?php the_content(); wp_link_pages(); ?></div>
    </div>
<?php endwhile; get_footer(); ?>
