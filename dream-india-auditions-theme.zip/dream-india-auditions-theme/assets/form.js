(() => {
  'use strict';
  document.querySelectorAll('.dip-app').forEach((app) => {
    const form = app.querySelector('.dip-form');
    const status = app.querySelector('.dip-status');
    const success = app.querySelector('.dip-success');
    if (!form || !status || !success) return;
    const button = form.querySelector('button[type="submit"]');
    const label = button.querySelector('span');
    let requestId = '';
    let busy = false;

    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      if (busy || !form.reportValidity()) return;
      const config = window.DIP_CONFIG;
      if (!config || config.demo || !config.ajax || !config.nonce) {
        status.textContent = 'Registration is temporarily unavailable. Refresh the page and try again.';
        return;
      }
      busy = true;
      button.disabled = true;
      form.setAttribute('aria-busy', 'true');
      label.textContent = 'SUBMITTING…';
      status.textContent = 'Please wait while we save your registration.';
      try {
        if (!requestId) {
          requestId = window.crypto && typeof window.crypto.randomUUID === 'function'
            ? window.crypto.randomUUID()
            : Date.now() + '-' + Math.random().toString(36).slice(2) + '-' + Math.random().toString(36).slice(2);
        }
        const data = new URLSearchParams();
        new FormData(form).forEach((value, key) => data.append(key, value));
        data.set('request_id', requestId);
        data.set('action', 'dip_register');
        data.set('nonce', config.nonce);
        const response = await fetch(config.ajax, {
          method: 'POST', body: data, credentials: 'same-origin',
          headers: { Accept: 'application/json' }
        });
        let result;
        try { result = await response.json(); } catch (_) {
          throw new Error('The server could not complete your request. Please try again.');
        }
        if (!response.ok || !result.success || !result.data || !result.data.id) {
          throw new Error(result && result.data && result.data.message || 'Unable to submit. Please try again.');
        }
        success.querySelector('.dip-receipt').textContent = 'Your registration ID: ' + result.data.id + '. Your details have been received by Dream India Production.';
        form.hidden = true;
        success.hidden = false;
        const heading = success.querySelector('h2');
        heading.setAttribute('tabindex', '-1');
        heading.focus({ preventScroll: true });
        success.scrollIntoView({
          behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
          block: 'center'
        });
      } catch (error) {
        status.textContent = error.message || 'Connection failed. Please try again.';
      } finally {
        busy = false;
        button.disabled = false;
        form.removeAttribute('aria-busy');
        label.textContent = 'SUBMIT REGISTRATION';
      }
    });

    success.querySelector('button').addEventListener('click', () => {
      form.reset();
      requestId = '';
      status.textContent = '';
      success.hidden = true;
      form.hidden = false;
      form.querySelector('input').focus();
    });
  });
})();
