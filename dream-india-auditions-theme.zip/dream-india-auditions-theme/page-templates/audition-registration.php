<?php
/**
 * Template Name: Audition Registration
 * Template Post Type: page
 */
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<div id="dia-content" tabindex="-1">
    <?php echo do_shortcode('[dream_india_audition]'); ?>
</div>
<?php get_footer(); ?>
