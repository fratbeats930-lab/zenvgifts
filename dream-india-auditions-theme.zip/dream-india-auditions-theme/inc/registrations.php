<?php
/** Private registration storage and Google Sheets integration for the theme. */
if (!defined('ABSPATH')) {
    exit;
}

function dia_theme_get_modes() {
    return array_values(array_filter(array_map('trim', explode("\n", (string) get_option('dip_modes', 'Online')))));
}

function dia_theme_register_entries() {
    $admin_caps = array_fill_keys(array(
        'edit_post', 'read_post', 'delete_post', 'edit_posts', 'edit_others_posts',
        'publish_posts', 'read_private_posts', 'delete_posts', 'delete_private_posts',
        'delete_published_posts', 'delete_others_posts', 'edit_private_posts',
        'edit_published_posts', 'read',
    ), 'manage_options');
    $admin_caps['create_posts'] = 'do_not_allow';
    register_post_type('dip_registration', array(
        'label' => 'Audition Entries',
        'public' => false,
        'publicly_queryable' => false,
        'exclude_from_search' => true,
        'show_ui' => true,
        'show_in_rest' => false,
        'rewrite' => false,
        'query_var' => false,
        'supports' => array('title'),
        'capability_type' => 'post',
        'capabilities' => $admin_caps,
        'map_meta_cap' => false,
    ));
}
add_action('init', 'dia_theme_register_entries');

function dia_theme_valid_endpoint($url) {
    return is_string($url) && (bool) preg_match('~\Ahttps://script\.google\.com/macros/s/[a-zA-Z0-9_-]+/exec\z~', $url);
}

function dia_theme_clean_endpoint($value) {
    $value = is_string($value) ? trim($value) : '';
    if ($value !== '' && !dia_theme_valid_endpoint($value)) {
        add_settings_error('dip_endpoint', 'invalid_endpoint', 'Use the HTTPS Google Apps Script web app URL ending in /exec.');
        return get_option('dip_endpoint', '');
    }
    return $value;
}

function dia_theme_clean_token($value) {
    $value = is_string($value) ? trim($value) : '';
    if ($value !== '' && (strlen($value) < 32 || preg_match('/[\x00-\x1f\x7f]/', $value))) {
        add_settings_error('dip_token', 'invalid_token', 'Use a random shared secret of at least 32 characters. The previous value was kept.');
        return get_option('dip_token', '');
    }
    return $value;
}

function dia_theme_register_settings() {
    register_setting('dip', 'dip_endpoint', array('sanitize_callback' => 'dia_theme_clean_endpoint'));
    register_setting('dip', 'dip_token', array('sanitize_callback' => 'dia_theme_clean_token'));
    register_setting('dip', 'dip_modes', array('sanitize_callback' => 'sanitize_textarea_field'));
    register_setting('dip', 'dip_logo_url', array('sanitize_callback' => 'esc_url_raw'));
}
add_action('admin_init', 'dia_theme_register_settings');

function dia_theme_settings_menu() {
    add_options_page('Dream India Auditions', 'Dream India Auditions', 'manage_options', 'dip-settings', 'dia_theme_settings_page');
}
add_action('admin_menu', 'dia_theme_settings_menu');

function dia_theme_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    ?>
    <div class="wrap">
        <h1>Dream India Production — Audition Setup</h1>
        <p>The theme home page includes the registration form. You can also add <code>[dream_india_audition]</code> to a page.</p>
        <p>Connect the included Google Apps Script to receive registrations. A private copy is saved in Audition Entries before syncing. Pending entries retry hourly when WordPress cron runs.</p>
        <?php settings_errors(); ?>
        <form action="options.php" method="post">
            <?php settings_fields('dip'); ?>
            <table class="form-table" role="presentation">
                <tr><th scope="row"><label for="dia-endpoint">Apps Script /exec URL</label></th><td><input id="dia-endpoint" class="large-text" name="dip_endpoint" type="url" value="<?php echo esc_attr(get_option('dip_endpoint', '')); ?>"></td></tr>
                <tr><th scope="row"><label for="dia-token">Shared secret</label></th><td><input id="dia-token" class="regular-text" name="dip_token" type="password" autocomplete="new-password" value="<?php echo esc_attr(get_option('dip_token', '')); ?>"><p class="description">Use the same random secret (at least 32 characters) in Google Apps Script. Keep it private. Clearing it closes registration.</p></td></tr>
                <tr><th scope="row"><label for="dia-logo">Company logo URL</label></th><td><input id="dia-logo" class="large-text" name="dip_logo_url" type="url" value="<?php echo esc_attr(get_option('dip_logo_url', '')); ?>"><p class="description">Upload your company logo in Media Library and paste its HTTPS URL here.</p></td></tr>
                <tr><th scope="row"><label for="dia-modes">Audition modes</label></th><td><textarea id="dia-modes" name="dip_modes" rows="7" cols="40"><?php echo esc_textarea(get_option('dip_modes', 'Online')); ?></textarea><p class="description">One available mode per line, for example Online or In-person. Only list modes you offer.</p></td></tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

/** Use a unique value so an expired request cannot release a newer request's lock. */
function dia_theme_acquire_lock($name) {
    $value = time() . ':' . wp_generate_uuid4();
    if (add_option($name, $value, '', false)) {
        return $value;
    }
    $previous = get_option($name, '');
    // Also recognizes the timestamp-only locks created by the original plugin.
    if ((int) $previous > 0 && (int) $previous < time() - 120) {
        dia_theme_release_lock($name, $previous);
        if (add_option($name, $value, '', false)) {
            return $value;
        }
    }
    return false;
}

function dia_theme_release_lock($name, $value) {
    global $wpdb;
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", $name, (string) $value));
    wp_cache_delete($name, 'options');
}

function dia_theme_registration_result($data) {
    $existing = get_posts(array(
        'post_type' => 'dip_registration', 'post_status' => 'private',
        'meta_key' => 'dip_request_id', 'meta_value' => $data['request_id'],
        'fields' => 'ids', 'posts_per_page' => 1,
    ));
    if ($existing) {
        $old = get_post_meta($existing[0], 'dip_data', true);
        if (is_array($old) && !empty($old['registration_id'])) {
            return array('success' => true, 'id' => $old['registration_id']);
        }
        return array('success' => false, 'status' => 500, 'message' => 'Your previous registration could not be read. Please contact Dream India Production.');
    }

    $ip = isset($_SERVER['REMOTE_ADDR']) && is_string($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown';
    $ipkey = 'dip_rate_' . hash_hmac('sha256', $ip, wp_salt());
    $count = (int) get_transient($ipkey);
    if ($count >= 5) {
        return array('success' => false, 'status' => 429, 'message' => 'Too many submissions. Please try again in 10 minutes.');
    }

    $request_id = $data['request_id'];
    unset($data['request_id']);
    $data['registration_id'] = 'DIP-' . strtoupper(substr(str_replace('-', '', wp_generate_uuid4()), 0, 12));
    $data['timestamp_ist'] = (new DateTimeImmutable('now', new DateTimeZone('Asia/Kolkata')))->format('Y-m-d H:i:s');
    $data['timezone'] = 'Asia/Kolkata';
    $id = wp_insert_post(array(
        'post_type' => 'dip_registration', 'post_status' => 'private',
        'post_title' => $data['registration_id'] . ' — ' . $data['full_name'],
    ), true);
    if (is_wp_error($id) || !$id) {
        return array('success' => false, 'status' => 500, 'message' => 'Could not save your registration. Please try again.');
    }
    update_post_meta($id, 'dip_request_id', $request_id);
    update_post_meta($id, 'dip_data', $data);
    update_post_meta($id, 'dip_sync', 'pending');
    if (get_post_meta($id, 'dip_request_id', true) !== $request_id || get_post_meta($id, 'dip_data', true) !== $data) {
        wp_delete_post($id, true);
        return array('success' => false, 'status' => 500, 'message' => 'Could not save your registration. Please try again.');
    }
    set_transient($ipkey, $count + 1, 10 * MINUTE_IN_SECONDS);
    // The local receipt remains valid even when Google Sheets is temporarily unavailable.
    dia_theme_sync_registration($id);
    return array('success' => true, 'id' => $data['registration_id']);
}

function dia_theme_register() {
    if (!isset($_POST['nonce']) || !is_string($_POST['nonce']) || !wp_verify_nonce(wp_unslash($_POST['nonce']), 'dip_register')) {
        wp_send_json_error(array('message' => 'Page expired. Refresh this page and try again.'), 403);
    }
    if (!empty($_POST['website'])) {
        wp_send_json_error(array('message' => 'Unable to submit.'), 400);
    }
    if (!dia_theme_valid_endpoint(get_option('dip_endpoint', '')) || strlen((string) get_option('dip_token', '')) < 32) {
        wp_send_json_error(array('message' => 'Registration is not open yet. Please try again later.'), 503);
    }
    $data = array();
    foreach (array('full_name', 'age', 'gender', 'whatsapp', 'alternate', 'email', 'city', 'audition_mode', 'request_id', 'consent') as $key) {
        if (isset($_POST[$key]) && !is_string($_POST[$key])) {
            wp_send_json_error(array('message' => 'Invalid form data.'), 400);
        }
        $data[$key] = sanitize_text_field(wp_unslash(isset($_POST[$key]) ? $_POST[$key] : ''));
    }
    if (strlen($data['full_name']) < 2 || strlen($data['full_name']) > 100 || !ctype_digit($data['age']) || (int) $data['age'] < 5 || (int) $data['age'] > 100
        || !in_array($data['gender'], array('Female', 'Male', 'Other', 'Prefer not to say'), true)
        || !preg_match('/\A[6-9][0-9]{9}\z/', $data['whatsapp'])
        || ($data['alternate'] !== '' && !preg_match('/\A[6-9][0-9]{9}\z/', $data['alternate']))
        || ($data['email'] !== '' && (!is_email($data['email']) || strlen($data['email']) > 150))
        || strlen($data['city']) < 2 || strlen($data['city']) > 100
        || !in_array($data['audition_mode'], dia_theme_get_modes(), true) || $data['consent'] !== '1'
        || !preg_match('/\A[a-zA-Z0-9-]{10,80}\z/', $data['request_id'])) {
        wp_send_json_error(array('message' => 'Please check your name, age, mobile number, city and consent.'), 400);
    }

    $lock = 'dip_lock_' . hash('sha256', $data['request_id']);
    $lock_value = dia_theme_acquire_lock($lock);
    if ($lock_value === false) {
        wp_send_json_error(array('message' => 'This registration is being processed. Please retry shortly.'), 409);
    }
    // Send JSON only after finally: WordPress JSON helpers terminate the request.
    try {
        $result = dia_theme_registration_result($data);
    } catch (Throwable $error) {
        $result = array('success' => false, 'status' => 500, 'message' => 'Unable to complete your registration. Please try again.');
    } finally {
        dia_theme_release_lock($lock, $lock_value);
    }
    if ($result['success']) {
        wp_send_json_success(array('id' => $result['id']));
    }
    wp_send_json_error(array('message' => $result['message']), $result['status']);
}
add_action('wp_ajax_nopriv_dip_register', 'dia_theme_register');
add_action('wp_ajax_dip_register', 'dia_theme_register');

function dia_theme_sync_registration($id) {
    $url = get_option('dip_endpoint', '');
    $token = (string) get_option('dip_token', '');
    if (!dia_theme_valid_endpoint($url) || strlen($token) < 32 || get_post_meta($id, 'dip_sync', true) === 'synced') {
        return;
    }
    $data = get_post_meta($id, 'dip_data', true);
    if (!is_array($data) || empty($data['registration_id'])) {
        return;
    }
    $data['secret'] = $token;
    $response = wp_safe_remote_post($url, array(
        'timeout' => 20, 'redirection' => 5, 'sslverify' => true, 'limit_response_size' => 16384,
        'headers' => array('Content-Type' => 'application/json'), 'body' => wp_json_encode($data),
    ));
    $body = is_wp_error($response) ? array() : json_decode(wp_remote_retrieve_body($response), true);
    if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200 && is_array($body)
        && !empty($body['ok']) && isset($body['registration_id']) && $body['registration_id'] === $data['registration_id']) {
        update_post_meta($id, 'dip_sync', 'synced');
    }
}

function dia_theme_retry_registrations() {
    $ids = get_posts(array(
        'post_type' => 'dip_registration', 'post_status' => 'private',
        'meta_key' => 'dip_sync', 'meta_value' => 'pending',
        'numberposts' => 25, 'orderby' => 'date', 'order' => 'ASC', 'fields' => 'ids',
    ));
    foreach ($ids as $id) {
        dia_theme_sync_registration($id);
    }
}
add_action('dip_retry', 'dia_theme_retry_registrations');

function dia_theme_schedule_retry() {
    if (!wp_next_scheduled('dip_retry')) {
        wp_schedule_event(time() + 60, 'hourly', 'dip_retry');
    }
}
add_action('after_switch_theme', 'dia_theme_schedule_retry');
add_action('init', 'dia_theme_schedule_retry');

function dia_theme_unschedule_retry() {
    wp_clear_scheduled_hook('dip_retry');
}
add_action('switch_theme', 'dia_theme_unschedule_retry');

function dia_theme_registration_meta_boxes() {
    add_meta_box('dip-details', 'Registration details', 'dia_theme_registration_details', 'dip_registration');
}
add_action('add_meta_boxes', 'dia_theme_registration_meta_boxes');

function dia_theme_registration_details($post) {
    if (!current_user_can('manage_options')) {
        return;
    }
    $data = get_post_meta($post->ID, 'dip_data', true);
    echo '<p><strong>Google Sheets: ' . esc_html(get_post_meta($post->ID, 'dip_sync', true)) . '</strong></p><table>';
    foreach ((array) $data as $key => $value) {
        if (!is_scalar($value)) {
            continue;
        }
        echo '<tr><th style="text-align:left;padding:7px">' . esc_html(ucwords(str_replace('_', ' ', $key))) . '</th><td>' . esc_html($value) . '</td></tr>';
    }
    echo '</table>';
}
