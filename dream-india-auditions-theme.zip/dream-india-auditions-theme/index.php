<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<main id="dia-content" class="dia-content-shell" tabindex="-1">
    <nav class="dia-page-brand" aria-label="Home"><a href="<?php echo esc_url(home_url('/')); ?>">Dream India Production</a><a href="<?php echo esc_url(home_url('/')); ?>">Audition Registration ↗</a></nav>
    <?php if (have_posts()) : ?>
        <?php while (have_posts()) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <?php if (is_singular()) : ?>
                    <h1><?php the_title(); ?></h1>
                <?php else : ?>
                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                <?php endif; ?>
                <div class="dia-entry-content"><?php the_content(); wp_link_pages(); ?></div>
            </article>
        <?php endwhile; ?>
        <?php the_posts_navigation(); ?>
    <?php else : ?>
        <h1><?php esc_html_e('No content found', 'dream-india-auditions-theme'); ?></h1>
        <p><a href="<?php echo esc_url(home_url('/')); ?>">Go to audition registration</a></p>
    <?php endif; ?>
</main>
<?php get_footer(); ?>
