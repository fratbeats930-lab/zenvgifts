<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<main id="dia-content" class="dia-content-shell" tabindex="-1">
    <h1><?php esc_html_e('Page not found', 'dream-india-auditions-theme'); ?></h1>
    <p><?php esc_html_e('This page could not be found. You can still register for an audition.', 'dream-india-auditions-theme'); ?></p>
    <p><a href="<?php echo esc_url(home_url('/')); ?>">Go to audition registration ↗</a></p>
</main>
<?php get_footer(); ?>
