<?php
/** Theme setup and audition form rendering. */
if (!defined('ABSPATH')) {
    exit;
}

define('DIA_THEME_VERSION', '1.2.0');

function dia_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('responsive-embeds');
    add_theme_support('html5', array('search-form', 'gallery', 'caption', 'style', 'script'));
    add_theme_support('custom-logo', array('height' => 130, 'width' => 260, 'flex-width' => true, 'flex-height' => true));
    load_theme_textdomain('dream-india-auditions-theme', get_template_directory() . '/languages');
}
add_action('after_setup_theme', 'dia_theme_setup');

// Retain the original plugin's data and handlers if it is already active.
// Otherwise this theme supplies the complete registration backend itself.
if (!function_exists('dip_register')) {
    require_once get_template_directory() . '/inc/registrations.php';
}

function dia_theme_assets() {
    wp_enqueue_style('dia-theme', get_stylesheet_uri(), array(), DIA_THEME_VERSION);
    wp_enqueue_style('dip-form', get_template_directory_uri() . '/assets/form.css', array('dia-theme'), DIA_THEME_VERSION);
    wp_enqueue_script('dip-form', get_template_directory_uri() . '/assets/form.js', array(), DIA_THEME_VERSION, true);
    wp_localize_script('dip-form', 'DIP_CONFIG', array(
        'ajax' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('dip_register'),
        'demo' => false,
    ));
}
add_action('wp_enqueue_scripts', 'dia_theme_assets');

function dia_theme_registration_modes() {
    if (function_exists('dia_theme_get_modes')) {
        return dia_theme_get_modes();
    }
    return function_exists('dip_modes') ? dip_modes() : array('Online');
}

function dia_theme_render_registration() {
    static $rendered = false;
    if ($rendered) {
        return '';
    }
    $file = get_template_directory() . '/assets/form.html';
    if (!is_readable($file)) {
        return '<p>' . esc_html__('The registration form is temporarily unavailable.', 'dream-india-auditions-theme') . '</p>';
    }
    $rendered = true;
    $modes = '';
    foreach (dia_theme_registration_modes() as $mode) {
        $modes .= '<option value="' . esc_attr($mode) . '">' . esc_html($mode) . '</option>';
    }
    $logo_url = (string) get_option('dip_logo_url', '');
    if (!$logo_url && has_custom_logo()) {
        $logo_url = (string) wp_get_attachment_image_url(get_theme_mod('custom_logo'), 'full');
    }
    $logo = $logo_url
        ? '<img class="dip-logo" src="' . esc_url($logo_url) . '" alt="Dream India Production">'
        : '<span class="dip-mark dip-logo dip-logo-mark" aria-hidden="true">♫</span>';
    return strtr(file_get_contents($file), array(
        '__ASSET__' => esc_url(get_template_directory_uri() . '/assets'),
        '__MODES__' => $modes,
        '__YEAR__' => esc_html(wp_date('Y')),
        '__LOGO__' => $logo,
    ));
}
add_shortcode('dream_india_audition', 'dia_theme_render_registration');

function dia_theme_setup_notice() {
    if (!current_user_can('manage_options')) {
        return;
    }
    if (!get_option('dip_endpoint', '') || strlen((string) get_option('dip_token', '')) < 32) {
        echo '<div class="notice notice-warning"><p>Dream India Auditions: connect Google Sheets in <a href="' . esc_url(admin_url('options-general.php?page=dip-settings')) . '">Settings → Dream India Auditions</a> to open registration. The website design is ready; submissions stay closed until these settings are saved. Setup instructions are included in SETUP-HINDI.txt.</p></div>';
    }
}
add_action('admin_notices', 'dia_theme_setup_notice');
