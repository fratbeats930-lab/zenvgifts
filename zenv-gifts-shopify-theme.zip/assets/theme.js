/* Zen V Gifts — native Shopify storefront enhancements. */
(() => {
  'use strict';

  const root = `${window.Shopify?.routes?.root || '/'}`.replace(/\/?$/, '/');
  const currency = window.themeCurrency || 'INR';
  const formatter = new Intl.NumberFormat(document.documentElement.lang || 'en-IN', {
    style: 'currency', currency, maximumFractionDigits: 2,
  });
  const money = (cents) => formatter.format((Number(cents) || 0) / 100);
  const find = (selector, scope = document) => scope.querySelector(selector);
  const all = (selector, scope = document) => [...scope.querySelectorAll(selector)];
  const live = find('[data-cart-live]');
  const cartDrawer = find('[data-cart-drawer]');
  const cartItems = find('[data-cart-items]');
  const cartError = find('[data-cart-error]');
  let activeLayer = null;
  let previousFocus = null;
  let cartVersion = 0;
  let cartBusy = false;
  let cartEmpty = true;
  let cartLoad = null;

  function announce(message) {
    if (!live) return;
    live.textContent = '';
    window.setTimeout(() => { live.textContent = message; }, 30);
  }

  function focusableElements(layer) {
    return all('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])', layer)
      .filter((element) => !element.hidden && element.getClientRects().length > 0 && element.getAttribute('aria-hidden') !== 'true');
  }

  function layerToggles(layer) {
    if (layer === cartDrawer) return all('[data-cart-toggle]');
    if (layer?.matches('[data-mobile-menu]')) return all('[data-menu-toggle]');
    return all('[data-search-toggle]');
  }

  function closeLayer(restoreFocus = true) {
    if (!activeLayer) return;
    const layer = activeLayer;
    layer.hidden = true;
    layer.setAttribute('aria-hidden', 'true');
    layerToggles(layer).forEach((toggle) => toggle.setAttribute('aria-expanded', 'false'));
    document.body.classList.remove('has-overlay');
    activeLayer = null;
    if (restoreFocus && previousFocus?.isConnected) previousFocus.focus();
  }

  function openLayer(layer, trigger) {
    if (!layer) return;
    if (activeLayer === layer) {
      closeLayer();
      return;
    }
    if (activeLayer) closeLayer(false);
    previousFocus = trigger || document.activeElement;
    activeLayer = layer;
    layer.hidden = false;
    layer.setAttribute('aria-hidden', 'false');
    layerToggles(layer).forEach((toggle) => toggle.setAttribute('aria-expanded', 'true'));
    document.body.classList.add('has-overlay');
    const focusTarget = find('[data-search-input], input[type="search"], [autofocus]', layer)
      || focusableElements(layer)[0] || layer;
    if (!focusTarget.hasAttribute('tabindex') && focusTarget === layer) layer.tabIndex = -1;
    focusTarget.focus({ preventScroll: true });
  }

  const menu = find('[data-mobile-menu]');
  const search = find('[data-search-panel]');
  all('[data-menu-toggle]').forEach((button) => button.addEventListener('click', () => openLayer(menu, button)));
  all('[data-search-toggle]').forEach((button) => button.addEventListener('click', () => openLayer(search, button)));
  all('[data-cart-toggle]').forEach((button) => button.addEventListener('click', (event) => {
    if (!cartDrawer) return;
    event.preventDefault();
    const opening = activeLayer !== cartDrawer;
    openLayer(cartDrawer, button);
    if (opening && !cartBusy) loadCart().catch(showCartError);
  }));
  all('[data-cart-close], [data-menu-close], [data-search-close], [data-overlay-close]').forEach((button) => {
    button.addEventListener('click', () => closeLayer());
  });
  [menu, search, cartDrawer].filter(Boolean).forEach((layer) => {
    layer.addEventListener('click', (event) => {
      if (event.target.matches('[data-cart-overlay], [data-menu-overlay], [data-search-overlay], [data-dialog-backdrop]')) closeLayer();
    });
  });
  menu?.addEventListener('click', (event) => {
    if (event.target.closest('a[href]')) closeLayer(false);
  });
  document.addEventListener('keydown', (event) => {
    if (!activeLayer) return;
    if (event.key === 'Escape') {
      event.preventDefault();
      closeLayer();
    } else if (event.key === 'Tab') {
      const elements = focusableElements(activeLayer);
      if (!elements.length) {
        event.preventDefault();
        activeLayer.focus();
      } else if (event.shiftKey && (document.activeElement === elements[0] || !activeLayer.contains(document.activeElement))) {
        event.preventDefault();
        elements[elements.length - 1].focus();
      } else if (!event.shiftKey && (document.activeElement === elements[elements.length - 1] || !activeLayer.contains(document.activeElement))) {
        event.preventDefault();
        elements[0].focus();
      }
    }
  });

  async function request(path, options = {}) {
    const response = await fetch(`${root}${path}`, {
      credentials: 'same-origin',
      ...options,
      headers: { Accept: 'application/json', ...options.headers },
    });
    const type = response.headers.get('content-type') || '';
    if (!type.includes('application/json')) {
      throw new Error('Your cart could not be reached. Please refresh the page and try again.');
    }
    const result = await response.json();
    if (!response.ok) {
      const description = typeof result.description === 'string' ? result.description : '';
      const message = typeof result.message === 'string' ? result.message : '';
      throw new Error(description || message || 'We could not update your cart. Please try again.');
    }
    return result;
  }

  function clearCartError() {
    if (!cartError) return;
    cartError.textContent = '';
    cartError.hidden = true;
  }

  function showCartError(error) {
    const message = error?.message || 'Please check your connection and try again.';
    if (cartError) {
      cartError.textContent = message;
      cartError.hidden = false;
    }
    announce(message);
  }

  function updateCheckout() {
    all('[data-cart-checkout]').forEach((checkout) => {
      const unavailable = cartBusy || cartEmpty;
      checkout.setAttribute('aria-disabled', String(unavailable));
      if ('disabled' in checkout) checkout.disabled = unavailable;
      if (checkout.tagName === 'A') checkout.tabIndex = unavailable ? -1 : 0;
    });
  }

  function setCartBusy(busy) {
    cartBusy = busy;
    cartDrawer?.setAttribute('aria-busy', String(busy));
    all('[data-cart-action]').forEach((button) => { button.disabled = busy; });
    updateCheckout();
  }

  all('[data-cart-checkout]').forEach((checkout) => {
    checkout.addEventListener('click', (event) => {
      if (cartBusy || cartEmpty) event.preventDefault();
    });
  });

  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function cartAction(action, key, label, text) {
    const button = element('button', action === 'remove' ? 'cart-item__remove' : 'quantity-control__button', text);
    button.type = 'button';
    button.dataset.cartAction = action;
    button.dataset.itemKey = key;
    button.setAttribute('aria-label', label);
    button.disabled = cartBusy;
    return button;
  }

  function safeURL(value) {
    if (!value || typeof value !== 'string') return '';
    try {
      const url = new URL(value, window.location.origin);
      return ['http:', 'https:'].includes(url.protocol) ? url.href : '';
    } catch (_) {
      return '';
    }
  }

  function renderCart(cart) {
    if (!cart || !Array.isArray(cart.items)) throw new Error('Your cart could not be loaded. Please try again.');
    cartEmpty = cart.item_count === 0;
    all('[data-cart-count]').forEach((count) => {
      count.textContent = String(cart.item_count);
      count.setAttribute('aria-label', `${cart.item_count} ${cart.item_count === 1 ? 'item' : 'items'} in cart`);
    });
    all('[data-cart-subtotal]').forEach((subtotal) => {
      subtotal.textContent = money(cart.items_subtotal_price ?? cart.total_price);
    });
    all('[data-cart-empty]').forEach((empty) => { empty.hidden = !cartEmpty; });
    if (cartItems) {
      const fragment = document.createDocumentFragment();
      cart.items.forEach((item) => {
        const row = element('article', 'cart-item');
        row.dataset.itemKey = item.key;
        const productURL = safeURL(item.url || `${root}products/${encodeURIComponent(item.handle || '')}`);
        const pictureURL = safeURL(item.image || item.featured_image?.url || '');
        if (pictureURL) {
          const imageLink = element('a', 'cart-item__image-link');
          imageLink.href = productURL;
          imageLink.tabIndex = -1;
          imageLink.setAttribute('aria-hidden', 'true');
          const image = element('img', 'cart-item__image');
          image.src = pictureURL;
          image.alt = '';
          image.width = 88;
          image.height = 104;
          image.loading = 'lazy';
          imageLink.append(image);
          row.append(imageLink);
        }
        const details = element('div', 'cart-item__details');
        const title = element('a', 'cart-item__title', item.product_title || item.title);
        title.href = productURL;
        details.append(title);
        if (item.variant_title && item.variant_title !== 'Default Title') {
          details.append(element('p', 'cart-item__variant', item.variant_title));
        }
        Object.entries(item.properties || {}).forEach(([key, value]) => {
          if (key.startsWith('_') || !value) return;
          details.append(element('p', 'cart-item__property', `${key}: ${value}`));
        });
        details.append(element('p', 'cart-item__price', money(item.final_line_price ?? item.line_price)));
        const bottom = element('div', 'cart-item__quantity');
        const quantity = element('div', 'quantity-control');
        quantity.setAttribute('role', 'group');
        quantity.setAttribute('aria-label', `Quantity for ${item.product_title || item.title}`);
        quantity.append(cartAction('decrease', item.key, `Decrease quantity of ${item.product_title || item.title}`, '−'));
        const count = element('span', 'quantity-control__value', String(item.quantity));
        count.setAttribute('aria-label', `Quantity: ${item.quantity}`);
        quantity.append(count);
        quantity.append(cartAction('increase', item.key, `Increase quantity of ${item.product_title || item.title}`, '+'));
        bottom.append(quantity, cartAction('remove', item.key, `Remove ${item.product_title || item.title}`, 'Remove'));
        details.append(bottom);
        row.append(details);
        fragment.append(row);
      });
      cartItems.replaceChildren(fragment);
    }
    updateCheckout();
    window.dispatchEvent(new CustomEvent('cart:updated', { detail: { cart } }));
  }

  function loadCart(force = false) {
    if (cartLoad && !force) return cartLoad;
    const version = ++cartVersion;
    clearCartError();
    const operation = request('cart.js').then((cart) => {
      if (version === cartVersion) renderCart(cart);
      return cart;
    });
    cartLoad = operation;
    operation.finally(() => {
      if (cartLoad === operation) cartLoad = null;
    }).catch(() => {});
    return operation;
  }

  cartItems?.addEventListener('click', async (event) => {
    const button = event.target.closest('[data-cart-action]');
    if (!button || cartBusy) return;
    const row = button.closest('.cart-item');
    const quantity = Number(find('.quantity-control__value', row)?.textContent) || 1;
    const next = button.dataset.cartAction === 'remove' ? 0
      : quantity + (button.dataset.cartAction === 'increase' ? 1 : -1);
    const key = button.dataset.itemKey;
    const action = button.dataset.cartAction;
    clearCartError();
    ++cartVersion;
    setCartBusy(true);
    try {
      const cart = await request('cart/change.js', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: key, quantity: Math.max(0, next) }),
      });
      renderCart(cart);
      announce(next <= 0 ? 'Item removed from your cart.' : `Cart updated. Quantity ${next}.`);
      const nextButton = all('[data-cart-action]', cartItems).find((candidate) => candidate.dataset.itemKey === key && candidate.dataset.cartAction === action);
      // Wait until controls are enabled before restoring focus after re-rendering.
      setCartBusy(false);
      (nextButton || find('[data-cart-close]', cartDrawer))?.focus({ preventScroll: true });
    } catch (error) {
      showCartError(error);
    } finally {
      setCartBusy(false);
    }
  });

  function productScope(form) {
    return form.closest('[data-product], [data-product-section]') || form;
  }

  function productError(form, message) {
    let error = find('[data-product-error]', form) || find('[data-product-error]', productScope(form));
    if (!error) {
      error = element('p', 'product-form__error');
      error.dataset.productError = '';
      error.setAttribute('role', 'status');
      form.append(error);
    }
    error.textContent = message;
    error.hidden = !message;
  }

  all('[data-product-form]').forEach((form) => {
    const scope = productScope(form);
    const variantSelect = find('[data-variant-select]', form);
    const button = find('[data-add-to-cart]', form);
    const buttonText = button && (find('[data-add-to-cart-text], [data-add-to-cart-label]', button) || button);
    const initialLabel = buttonText?.textContent.trim() || '';
    const defaultLabel = button?.dataset.addLabel || (/sold out|unavailable|choose an option/i.test(initialLabel) ? 'Add to bag' : initialLabel) || 'Add to bag';
    const json = find('[data-product-variants], [data-product-json]', form) || find('[data-product-variants], [data-product-json]', scope);
    let variants = [];
    if (json) {
      try {
        const parsed = JSON.parse(json.textContent);
        variants = Array.isArray(parsed) ? parsed : parsed.variants || [];
      } catch (_) { /* Native variant form remains available when JSON is absent. */ }
    }
    let adding = false;

    function selectedVariant() {
      const id = new FormData(form).get('id');
      return variants.find((variant) => String(variant.id) === String(id));
    }

    function updateVariant() {
      const variant = selectedVariant();
      const option = variantSelect?.selectedOptions?.[0];
      const available = variant ? variant.available : option?.dataset.available !== 'false';
      const hasSelection = Boolean(new FormData(form).get('id'));
      const quantityInput = find('input[name="quantity"]', form);
      if (quantityInput && variant?.quantity_rule) {
        const rule = variant.quantity_rule;
        quantityInput.min = String(rule.min || 1);
        quantityInput.step = String(rule.increment || 1);
        if (rule.max) quantityInput.max = String(rule.max);
        else quantityInput.removeAttribute('max');
        if (Number(quantityInput.value) < Number(quantityInput.min)) quantityInput.value = quantityInput.min;
      }
      all('[data-product-price]', scope).forEach((price) => {
        if (variant) price.textContent = money(variant.price);
        else if (option?.dataset.price) price.textContent = option.dataset.price;
      });
      all('[data-product-compare-price]', scope).forEach((compare) => {
        compare.hidden = !variant || !(variant.compare_at_price > variant.price);
        if (!compare.hidden) compare.textContent = money(variant.compare_at_price);
      });
      all('[data-product-availability]', scope).forEach((status) => {
        status.textContent = !hasSelection ? 'Choose an option' : available ? 'Available to gift' : 'Currently sold out';
        status.dataset.available = String(available && hasSelection);
      });
      if (button) button.disabled = adding || !available || !hasSelection;
      if (buttonText) buttonText.textContent = adding ? 'Adding…' : !hasSelection ? 'Choose an option' : available ? defaultLabel : 'Sold out';
    }

    variantSelect?.addEventListener('change', () => {
      productError(form, '');
      updateVariant();
      const variant = selectedVariant();
      if (variant && window.history.replaceState && window.location.pathname.includes('/products/')) {
        const url = new URL(window.location.href);
        url.searchParams.set('variant', variant.id);
        window.history.replaceState({}, '', url);
      }
    });
    updateVariant();

    form.addEventListener('submit', async (event) => {
      if (!window.fetch || !cartDrawer) return;
      event.preventDefault();
      productError(form, '');
      if (!form.reportValidity()) return;
      if (adding || cartBusy) {
        productError(form, 'Your cart is updating. Please try again in a moment.');
        return;
      }
      const data = new FormData(form);
      const variant = selectedVariant();
      if (!data.get('id') || (variants.length && !variant) || variant?.available === false || variantSelect?.selectedOptions?.[0]?.dataset.available === 'false') {
        productError(form, 'Please select an available option.');
        return;
      }
      const quantity = Number(data.get('quantity') || 1);
      if (!Number.isInteger(quantity) || quantity < 1) {
        productError(form, 'Please choose a quantity of at least 1.');
        return;
      }
      ++cartVersion;
      adding = true;
      setCartBusy(true);
      updateVariant();
      let added = false;
      try {
        await request('cart/add.js', { method: 'POST', body: data });
        added = true;
        await loadCart(true);
        if (activeLayer !== cartDrawer) openLayer(cartDrawer, button);
        announce('Added to your bag. Your cart has been updated.');
      } catch (error) {
        const message = added
          ? 'Your item was added, but the cart could not refresh. Open your cart or refresh the page to check it.'
          : error.message || 'This item could not be added. Please try again.';
        productError(form, message);
        announce(message);
      } finally {
        adding = false;
        setCartBusy(false);
        updateVariant();
      }
    });
  });

  all('[data-quantity-change]').forEach((button) => {
    button.addEventListener('click', () => {
      const input = find('input[name="quantity"]', button.closest('[data-quantity-selector]') || button.parentElement);
      if (!input) return;
      const minimum = Number(input.min) || 1;
      const maximum = Number(input.max) || Infinity;
      const value = Number(input.value) || minimum;
      input.value = Math.min(maximum, Math.max(minimum, value + Number(button.dataset.quantityChange || 0)));
      input.dispatchEvent(new Event('change', { bubbles: true }));
    });
  });

  const header = find('[data-header]');
  if (header) {
    let ticking = false;
    const updateHeader = () => {
      header.classList.toggle('is-scrolled', window.scrollY > 24);
      ticking = false;
    };
    updateHeader();
    window.addEventListener('scroll', () => {
      if (!ticking) {
        ticking = true;
        window.requestAnimationFrame(updateHeader);
      }
    }, { passive: true });
  }

  // Motion remains CSS controlled; expose the browser preference for optional UI.
  document.documentElement.classList.toggle('prefers-reduced-motion', window.matchMedia('(prefers-reduced-motion: reduce)').matches);
})();
